 $(document).ready(function(){
      $('.dropdown .btn_n').click(function(){
        $('.dropdown ul').toggle();
      });
      
    });